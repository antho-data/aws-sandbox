import boto3
import os

def handler(event, context):
    github_token = os.environ['GITHUBToken']
    s3bucket = os.environ['S3Bucket']
    cloudformation = boto3.client('cloudformation')

    # Construct the TemplateURL
    template_url = f'https://{s3bucket}.s3.amazonaws.com/aws-wipe-service.yaml'

    # Create the stack to nuke resources
    cloudformation.create_stack(
        StackName='cfn-nuke-stack',
        Capabilities=['CAPABILITY_IAM', 'CAPABILITY_NAMED_IAM'],
        TemplateURL=template_url,
        Parameters=[
            {'ParameterKey': 'GitUser', 'ParameterValue': 'antho-data'},
            {'ParameterKey': 'GitRepo', 'ParameterValue': 'aws-sandbox'},
            {'ParameterKey': 'GitBranch', 'ParameterValue': 'main'},
            {'ParameterKey': 'GitToken', 'ParameterValue': github_token},
            {'ParameterKey': 'AWSNukeVersionNumber', 'ParameterValue': '2.25.0'},
            {'ParameterKey': 'AWSNukeConfigFile', 'ParameterValue': 'aws-nuke-config/config.yaml'},
            {'ParameterKey': 'AWSNukeProfileName', 'ParameterValue': 'nuke'}
        ]
    )
