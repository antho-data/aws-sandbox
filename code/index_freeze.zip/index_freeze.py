import boto3
import os

def handler(event, context):
    group_name = 'datascientest-readonlyusers'
    policy_arn = 'arn:aws:iam::aws:policy/ReadOnlyAccess'
    
    iam = boto3.client('iam')
    
    # Verification if groupname exists
    try:
        iam.get_group(GroupName=group_name)
    except iam.exceptions.NoSuchEntityException:
        iam.create_group(GroupName=group_name)
        iam.attach_group_policy(GroupName=group_name, PolicyArn=policy_arn)

    # Make all users Read Only by adding them to the right group
    users = iam.list_users()
    for user in users['Users']:
        username = user['UserName']
        policies = iam.list_attached_user_policies(UserName=username)
        for policy in policies['AttachedPolicies']:
            iam.detach_user_policy(UserName=username, PolicyArn=policy['PolicyArn'])
        
        groups = iam.list_groups_for_user(UserName=username)
        for group in groups['Groups']:
            iam.remove_user_from_group(UserName=username, GroupName=group['GroupName'])

        iam.add_user_to_group(UserName=username, GroupName=group_name)

